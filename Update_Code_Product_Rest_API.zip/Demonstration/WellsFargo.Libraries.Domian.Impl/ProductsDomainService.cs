﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WellsFargo.Libraries.DataAccess.Interfaces;
using WellsFargo.Libraries.Domain.Interfaces;
using WellsFargo.Libraries.Models;

namespace WellsFargo.Libraries.Domian.Impl
{
    public class ProductsDomainService : IProductsDomainService
    {
        private const string INVALID_PRODUCT_PROFILE = "Invalid Product Details Specified for a New Entry!";

        private IProductsRepositories productsRepository = default(IProductsRepositories);
        public ProductsDomainService(IProductsRepositories productsRepository)
        {
            if (productsRepository == default(IProductsRepositories))
                throw new ArgumentNullException(nameof(productsRepository));

            this.productsRepository = productsRepository;
        }

        public ProductsModel AddNewProduct(ProductsModel productsModel)
        {
            var isParameterValid = productsModel != default(ProductsModel);

            if (!isParameterValid)
                throw new ApplicationException(INVALID_PRODUCT_PROFILE);

            var status = this.productsRepository.CreateNewProduct(productsModel);

            return status;

           // throw new NotImplementedException();
        }

        public IEnumerable<ProductsModel> GetAllProducts()
        {
            var result = default(IEnumerable<ProductsModel>);

            result = this.productsRepository.GetAllProductsList();

            return result;
        }

        public async Task<IEnumerable<ProductsModel>> GetProductsByID(int productId = 0)
        {

            var result = default(IEnumerable<ProductsModel>);
            if(productId != default(int))
            {
                result = await this.productsRepository.GetProductByID(productId);
            }

            return result;
        }

        public async Task<IEnumerable<ProductsModel>> GetProductsByName(string searchString)
        {
            var result = default(IEnumerable<ProductsModel>);
            if (searchString != null)
            {
                result = await this.productsRepository.GetProductByName(searchString);
            }

            return result;
        }

        public bool RemoveProduct(string productId)
        {
            var result= default(bool);
            if (productId != null)
            {
                result = this.productsRepository.RemoveProduct(productId);
            }

            return result;
        }
    }
}
