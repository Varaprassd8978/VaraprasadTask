﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WellFargo.Libraries.Services.Interfaces;
using WellsFargo.Libraries.Domain.Interfaces;
using WellsFargo.Libraries.Models;

namespace WellsFargo.Libraries.Services.Impl
{

    [Route("api/products")]
    [ApiController]
    public class ProductController : ControllerBase, IProductController
    {
        private IProductsDomainService productsDomainService = default;

        public ProductController(IProductsDomainService productsDomainService)
        {
            if (productsDomainService == default(IProductsDomainService))
                throw new ArgumentNullException(nameof(productsDomainService));

            this.productsDomainService = productsDomainService;
        }
        public IActionResult AddNewProduct(ProductsModel newProductModel)
        {
            throw new NotImplementedException();
        }

        [HttpDelete]
        [Route("delete/{productId}")]
        public bool DeleteProduct(string productId)
        {
            var deleteProduct =this. productsDomainService.RemoveProduct(productId);
           // var result = Ok(deleteProduct);
            return deleteProduct;
        }

        [HttpGet]
        [Route("")]
        public IActionResult GetAllProducts()
        {
            var allProductsList = default(IEnumerable<ProductsModel>);
            var result = default(IActionResult);

            allProductsList = this.productsDomainService.GetAllProducts();

            result = Ok(allProductsList);

            return result;
        }

        [HttpGet]
        [Route("details/{productId}")]
        public async Task<IActionResult> GetProductsListByID(int productId)
        {
            var productsListByID = default(IEnumerable<ProductsModel>);

            var result = default(IActionResult);

            productsListByID = await this.productsDomainService.GetProductsByID(productId);

            result = Ok(productsListByID);

            return result;

        }

        [HttpGet]
        [Route("search/{searchString}")]
        public async Task<IActionResult>GetProductsListByName(string searchString)
        {
            var productsListByName = default(IEnumerable<ProductsModel>);

            var result = default(IActionResult);

            productsListByName = await  this.productsDomainService.GetProductsByName(searchString);


            result = Ok(productsListByName);

            return result;

            

        }

        public IActionResult UpdateProduct(int customerProfileId)
        {
            throw new NotImplementedException();
        }

       
    }
}
