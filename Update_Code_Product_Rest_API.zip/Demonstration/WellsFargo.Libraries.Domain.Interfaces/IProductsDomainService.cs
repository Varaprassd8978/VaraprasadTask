﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WellsFargo.Libraries.Models;

namespace WellsFargo.Libraries.Domain.Interfaces
{
    public interface IProductsDomainService
    {
        Task<IEnumerable<ProductsModel>> GetProductsByName(string searchString);

        Task<IEnumerable<ProductsModel>> GetProductsByID(int productProfileId);

        public ProductsModel AddNewProduct(ProductsModel productsModel);

        public bool RemoveProduct(string productId);

        IEnumerable<ProductsModel> GetAllProducts();

    }
}
