﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;
using WellsFargo.Libraries.DataAccess.Interfaces;
using WellsFargo.Libraries.Models;
using WellsFargo.Libraries.ORM.Interfaces;
using MongoDB.Driver;

namespace WellFargo.Libraries.DataAccess.Impl
{
    public class ProductsRepositories : IProductsRepositories
    {
        private const string INVALID_PRODUCT_ID = "Invalid product ID Specified!";
        //private const string INVALID_SEARCH_STRING = "Invalid product Search String Specified!";
        private const string INVALID_ENTITY = "Invalid product Details Specified!";

        private readonly IProductsContext productsContext = default(IProductsContext);
        public ProductsRepositories(IProductsContext productsContext)
        {
            if (productsContext == default(IProductsContext))

                throw new ArgumentNullException(nameof(productsContext));

            this.productsContext = productsContext;
        }

        public ProductsModel CreateNewProduct(ProductsModel addNewProduct)
        {
            var isParameterValid = addNewProduct != default(ProductsModel) &&
                addNewProduct.ProductId != default(string);

            if (!isParameterValid) {
                throw new ArgumentException(INVALID_ENTITY);
            }
            this.productsContext.ProductsModels.InsertOne(addNewProduct);

            return addNewProduct;
           // throw new NotImplementedException();
        }

        public IEnumerable<ProductsModel> GetAllProductsList()
        {
            //var result = this.productsContext.ProductsModels
            var result = this.productsContext.ProductsModels.AsQueryable().ToList();
            var productsList = result;

            return productsList;
        }

        public async Task<IEnumerable<ProductsModel>> GetProductByID(int productID)
        {
            Expression<Func<ProductsModel, bool>> filter = p => p.ProductId == Convert.ToString(productID);

            var result = await this.productsContext.ProductsModels.FindAsync<ProductsModel>(filter);

            var productResults = await result.ToListAsync();

            return productResults;
        }

        public async Task<IEnumerable<ProductsModel>> GetProductByName(string productName)
        {
            Expression<Func<ProductsModel, bool>> filter = r => r.ProductTitle.ToLower().Contains(productName.ToLower());

            var result = await this.productsContext.ProductsModels.FindAsync<ProductsModel>(filter);

            var productResults = await result.ToListAsync();


            return productResults;

        }

        public ProductsModel GetProductsById(string id)
        {
            if (id == default(string))
                throw new ArgumentException(INVALID_PRODUCT_ID);

            var filteredProduct =
                this
                    .productsContext
                    .ProductsModels
                    .AsQueryable().Where(productsModel => productsModel.ProductId == id)
                    .FirstOrDefault();

            return filteredProduct;
        }

        public bool RemoveProduct(string id)
        {
            var isParameterValid = id != default(string);
           // var status = default(bool);

            //var filteredProduct = this.GetProductsById(id);
          var result=  this.productsContext.ProductsModels.DeleteOne<ProductsModel>(p => p.ProductId == id).ToString();

            return Convert.ToBoolean(result);
        }

        public ProductsModel UpdateProduct(ProductsModel exixstingProduct)
        {
            throw new NotImplementedException();
        }
    }
}