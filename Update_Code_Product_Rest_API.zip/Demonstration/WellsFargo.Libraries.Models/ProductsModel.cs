﻿using System;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
namespace WellsFargo.Libraries.Models
{
    public class ProductsModel
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string _id { get; set; }
        public string ProductId { get; set; }

        [BsonElement("producttitle")]
        public string ProductTitle { get; set; }

        [BsonElement("productdescription")]
        public string ProductDescription { get; set; }

        [BsonElement("unitcost")]
        public int UnitCost { get; set; }

        [BsonElement("unitdiscount")]
        public int UnitDiscount { get; set; }

        [BsonElement("stockavalialbe")]
        public int StockAvailable { get; set; }

        [BsonElement("rating")]
        public int Rating { get; set; }

    }
}
